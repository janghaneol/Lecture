package namoo.yorizori.controller.cookbook;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import namoo.yorizori.common.factory.JdbcDaoFactory;
import namoo.yorizori.common.factory.ServiceFactoryImpl;
import namoo.yorizori.dto.user.User;

/**
 * Servlet implementation class CookbookRegistController
 */
@WebServlet("/cookbook/register.do")
public class CookbookRegistController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String bookId = null;
		String bookName = request.getParameter("book_name");
		String bookDesc = request.getParameter("book_desc");
		String authorId = request.getParameter("author_id");
		
		HttpSession loginSession = request.getSession();
		
		if(loginSession != null) {
			bookId = loginSession.getId();
		}
	}

}
