package namoo.yorizori.dao.cookbook;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import namoo.yorizori.dto.cookbook.Cookbook;
import namoo.yorizori.dto.cookbook.Recipe;
import namoo.yorizori.service.cookbook.CookbookService;

public class JdbcCookbookDao implements CookbookDao{
	private DataSource dataSource;

	public JdbcCookbookDao(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	@Override
	public void registerCookbook(Cookbook cookbook) throws SQLException{
		Connection con = null;
		PreparedStatement pstmt = null;
		StringBuffer sb = new StringBuffer();
		sb.append(" INSERT INTO Cookbook(book_id, book_name, book_desc, author_id)")
          .append(" VALUES (?, ?, ?, ?)");
		
			con = dataSource.getConnection();
			pstmt = con.prepareStatement(sb.toString());
			pstmt.setString(1, cookbook.getBook_id());
			pstmt.setString(2, cookbook.getBook_name());
			pstmt.setString(3, cookbook.getBook_desc());
			pstmt.setString(4, cookbook.getAuthor_id());
			pstmt.executeUpdate();
	
		
			if(pstmt != null) 
				pstmt.close();
			if(con != null)
				con.close();
		
		
	}
	@Override
	public Cookbook findCookbookById(int bookid) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<Cookbook> findCookbookByAll() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void registerRecipe(Recipe recipe) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public Recipe findRecipeById(int recipeid) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<Recipe> findRecipeByAll() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
