package namoo.yorizori.common.factory;

import namoo.yorizori.dao.cookbook.CookbookDao;
import namoo.yorizori.dao.user.UserDao;

/**
 * DaoFactory에 대한 규약을 선언하는 인터페이스
 * @author 김기정
 *
 */
public interface DaoFactory {
	
	public UserDao getUserDao();
//	public BoardDao getBoardDao();
//	public XXXdDao getXXXDao();
	public CookbookDao getCookbookDao();

}
