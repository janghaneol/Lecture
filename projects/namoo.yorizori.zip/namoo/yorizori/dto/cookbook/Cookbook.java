package namoo.yorizori.dto.cookbook;

/**
 * Cookbook DTO
 * @author 김기정
 *
 */
public class Cookbook {

}
