package namoo.yorizori.dto.cookbook;

/**
 * Recipe DTO
 * @author 김기정
 *
 */
public class Recipe {

}
