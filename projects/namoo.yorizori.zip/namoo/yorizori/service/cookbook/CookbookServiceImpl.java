package namoo.yorizori.service.cookbook;

import java.util.List;

import namoo.yorizori.dto.cookbook.Cookbook;
import namoo.yorizori.dto.cookbook.Recipe;

public class CookbookServiceImpl implements CookbookService{

	@Override
	public void registerCookbook(Cookbook cookbook) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Cookbook findCookbookById(int bookid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Cookbook> findCookbookByAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void registerRecipe(Recipe recipe) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Recipe findRecipeById(int recipeid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Recipe> findRecipeByAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
