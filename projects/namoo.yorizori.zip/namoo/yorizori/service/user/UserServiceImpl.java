package namoo.yorizori.service.user;

import java.util.List;

import namoo.yorizori.common.web.Params;
import namoo.yorizori.dto.user.User;

public class UserServiceImpl implements UserService {

	@Override
	public void registerUser(User user) {
		// TODO Auto-generated method stub
	}

	@Override
	public User signIn(String id, String passwd) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User findById(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<User> findByAll(Params params) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int countUser(Params params) {
		// TODO Auto-generated method stub
		return 0;
	}

}
